/*
Name: Bethany Terry

Date: 31 March 2023

Assignment Description:Create a Sprite class in order to implement
polymorphism in the program. Create a boomerang file and a pot file.
Add pots to map and allow Link to throw boomerangs to smash pots.
 */

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Boomerang extends Sprite
{
    int xdirection = 0;
    int ydirection = 0;
    int speed = 10;
    boolean isValid = true;
    boolean isBroken = false;
    int isBrokenTimer = 10;

    public Boomerang(int x, int y)
    {
        this.x = x;
        this.y = y;
        w = 30;
        h = 30;
        if (this.image == null)
            this.image = View.loadImage("boomerang1.png");
    }

    public Boomerang(Json ob)
    {
        y = (int) ob.getLong("tile_y");
        x = (int) ob.getLong("tile_x");
        w = 15;
        h = 5;
        if (this.image == null)
            this.image = View.loadImage("boomerang1.png");
    }

    public boolean update()
    {
        x += speed * xdirection;
        y += speed * ydirection;

        return isValid;
    }

    public Json marshal()
    {
        Json ob = Json.newObject();
        ob.add("boomerang_x", x);
        ob.add("boomerang_y", y);
        return ob;
    }

    @Override
    boolean isBoomerang()
    {
        return true;
    }

    public void drawYourself(Graphics g)
    {
        g.drawImage(this.image, x - View.scrollPosX, y - View.scrollPosY, w, h, null);
    }
}