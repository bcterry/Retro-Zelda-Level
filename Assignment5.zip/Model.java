/*
Name: Bethany Terry

Date: 31 March 2023

Assignment Description:Create a Sprite class in order to implement
polymorphism in the program. Create a boomerang file and a pot file.
Add pots to map and allow Link to throw boomerangs to smash pots.
*/

import java.util.ArrayList;
import java.io.*;
import java.util.*;

//-----------------------------------------------------------
// Set tile coordinates
//-----------------------------------------------------------
class Model
{
	ArrayList<Sprite> sprites;
	Link link;

	boolean canAdd = true;
	boolean unmarshalling = false;

	int updatedTimes = 0;

	Model()
	{
		sprites = new ArrayList<Sprite>();
		link = new Link(120,120); //THIS IS DOWN CASTING
		sprites.add(link);

		Json loadFile = Json.load("map.json");
		unmarshal(loadFile);
	}

	Json marshal()
	{
		Json ob = Json.newObject();
		Json tmpListTiles = Json.newList();
		Json tmpListPots = Json.newList();
		ob.add("tiles", tmpListTiles);
		ob.add("pots", tmpListPots);
		for(int i = 0; i < sprites.size(); i++)
		{
			if(sprites.get(i).isTile())
			{
				tmpListTiles.add(sprites.get(i).marshal());
			}
			if(sprites.get(i).isPot())
				tmpListPots.add(sprites.get(i).marshal());
		}
		return ob;
	}

	void unmarshal(Json ob)
	{
		while(!canAdd)
		{}
		unmarshalling = true;
		if (canAdd) sprites.clear();
		if (canAdd) sprites.add(link);

		Json tmpListTiles = ob.get("tiles");
		Json tmpListPots = ob.get("pots");
		for(int i = 0; i < tmpListTiles.size(); i++)
			if (canAdd) sprites.add(new Tile(tmpListTiles.get(i)));
		for(int i = 0; i < tmpListPots.size(); i++)
			if (canAdd) sprites.add(new Pot(tmpListPots.get(i)));
		unmarshalling = false;
	}

	public void update()
	{
		if(unmarshalling)
			return;
		Iterator<Sprite> it = sprites.iterator();
		while(it.hasNext())
		{
			Sprite s = it.next();

			if (s.update() == false)
			{
				if (canAdd) it.remove();
			}

		}
		canAdd = false;
		for(Sprite sprite1: sprites)
		{
			for(Sprite sprite2: sprites)
			{
				if(sprite1.collisionDetection(sprite2))
				{
					if(sprite1.isLink() && sprite2.isTile())
						((Link)sprite1).getOutOfTile();

					if(sprite1.isLink() && sprite2.isPot())
					{
						Pot p = (Pot)sprite2;
						if(link.direction == 0)
							p.ydirection = 1;
						if(link.direction == 1)
							p.xdirection = -1;
						if(link.direction == 2)
							p.xdirection = 1;
						if(link.direction == 3)
							p.ydirection = -1;
					}
					if(sprite1.isLink() && sprite2.isBoomerang())
					{
						Boomerang b = (Boomerang)sprite2;
						if(link.direction == 0)
							b.ydirection = 1;
						if(link.direction == 1)
							b.xdirection = -1;
						if(link.direction == 2)
							b.xdirection = 1;
						if(link.direction == 3)
							b.ydirection = -1;
					}
					if(sprite1.isPot() && sprite2.isTile())
					{
						((Pot)sprite1).potHasBeenBroken();
					}
					if(sprite1.isBoomerang() && sprite2.isTile())
					{
						((Boomerang)sprite1).isValid = false;
						//if (canAdd) sprites.remove(sprite1);
					}
					if(sprite1.isBoomerang() && sprite2.isPot())
					{
						((Pot)sprite2).potHasBeenBroken();
						((Boomerang)sprite1).isValid = false;
						//if (canAdd) sprites.remove(sprite1);
					}
				}
			}
		}
		canAdd = true;
	}

	public void addTile(int mouseX, int mouseY)
	{
		int x = mouseX - mouseX % 50;
		int y = mouseY - mouseY % 50;
		boolean foundTile = false;
		for (int i = 0; i < sprites.size(); i++)
		{
			if(sprites.get(i).isTile() && sprites.get(i).amIClickingOnYou(mouseX, mouseY))
			{
				if (canAdd) sprites.remove(i);
				foundTile = true;
				System.out.println("Removed tile!");
				break;
			}
		}
		if (!foundTile && canAdd)
		{
			System.out.println("Not clicking on a tile!");
			Sprite s = new Tile(x, y);
			sprites.add((Tile)s);
		}
	}
	public void addPot(int mouseX, int mouseY)
	{
		boolean foundPot = false;
		for(int i = 0; i < sprites.size(); i++)
		{
			if(canAdd && sprites.get(i).isPot() && sprites.get(i).amIClickingOnYou(mouseX, mouseY))
			{
				sprites.remove(i);
				foundPot = true;
				System.out.println("Removed pot!");
				break;
			}
		}
		if(!foundPot && canAdd)
		{
			System.out.println("Not clicking on a Pot!");
			Sprite s = new Pot(mouseX,mouseY);
			sprites.add((Pot)s);
		}

	}

}