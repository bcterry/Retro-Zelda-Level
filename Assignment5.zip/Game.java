/*
Name: Bethany Terry

Date: 31 March 2023

Assignment Description:Create a Sprite class in order to implement
polymorphism in the program. Create a boomerang file and a pot file.
Add pots to map and allow Link to throw boomerangs to smash pots.
*/
import javax.swing.JFrame;
import java.awt.Toolkit;

//-----------------------------------------------------------
// Create pointers and objects for each created type
//-----------------------------------------------------------
public class Game extends JFrame
{
	Model model;
	Controller controller;
	View view;
	//-----------------------------------------------------------
	// Set parameters for JFrame
	//-----------------------------------------------------------
	public Game()
	{
		model = new Model();
		controller = new Controller(model);
		view = new View(controller, model);
		view.addMouseListener(controller);

		this.setTitle("A5 - Polymorphism");
		this.setSize(700, 500);
		this.setFocusable(true);
		this.getContentPane().add(view);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		this.addKeyListener(controller);
	}

	//-----------------------------------------------------------
	// Create a "new Game" object
	//-----------------------------------------------------------
	public static void main(String[] args)
	{
		Game g = new Game();
		g.run();
	}

	//-----------------------------------------------------------
	// Moves character on screen based on user input
	//-----------------------------------------------------------
	public void run()
	{
		while(true)
		{
			controller.update();
			model.update();
			view.repaint(); // This will indirectly call View.paintComponent
			Toolkit.getDefaultToolkit().sync(); // Updates screen


			// Go to sleep for 40 milliseconds
			try
			{
				Thread.sleep(40);
			} catch(Exception e) {
				e.printStackTrace();
				System.exit(1);
			}
		}
	}
}
