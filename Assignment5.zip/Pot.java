/*
        Name: Bethany Terry

        Date: 31 March 2023

        Assignment Description:Create a Sprite class in order to implement
        polymorphism in the program. Create a boomerang file and a pot file.
        Add pots to map and allow Link to throw boomerangs to smash pots.
 */

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Pot extends Sprite
{
    int xdirection = 0;
    int ydirection = 0;
    int speed = 10;
    boolean isValid = true;
    boolean isBroken = false;
    int isBrokenTimer = 10;

    public Pot(int x, int y)
    {
        this.x = x;
        this.y = y;
        w = 30;
        h = 30;
        if(this.image == null)
            this.image = View.loadImage("pot.png");
    }

    public Pot(Json ob)
    {
        if(this.image == null)
            this.image = View.loadImage("pot.png");

        y = (int)ob.getLong("pot_y");
        x = (int)ob.getLong("pot_x");
        w = 50;
        h = 50;

    }

    public boolean update()
    {
        x += speed * xdirection;
        y += speed * ydirection;
        if(isBroken) {
            isBrokenTimer--;
        }
        if(isBrokenTimer <= 0)
            isValid = false;

        return isValid;
    }

    public void potHasBeenBroken()
    {
        this.image = View.loadImage("pot_broken.png");
        isBroken = true;
        speed = 0;
    }

    @Override
    public String toString()
    {
        return "Pot: (" + x + ", " + y + ") ";
    }

    public void drawYourself(Graphics g)
    {
        g.drawImage(this.image, x - View.scrollPosX, y - View.scrollPosY, null);
    }

    @Override
    boolean isPot()
    {
        return true;
    }

    public Json marshal()
    {
        Json ob = Json.newObject();
        ob.add("pot_x", x);
        ob.add("pot_y", y);
        return ob;

    }


}