/*
Name: Bethany Terry

Date: 31 March 2023

Assignment Description:Create a Sprite class in order to implement
polymorphism in the program. Create a boomerang file and a pot file.
Add pots to map and allow Link to throw boomerangs to smash pots.
 */

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public abstract class Sprite
{
    int x, y, w, h;
    BufferedImage image;

    public abstract void drawYourself(Graphics g);
    public abstract boolean update();
    public abstract Json marshal();

    public boolean collisionDetection(Sprite sprite)
    {
        if(this.x + this.w < sprite.x)
            return false;
        if(this.x > sprite.x + sprite.w)
            return false;
        if(this.y + this.h < sprite.y)
            return false;
        if(this.y > sprite.y + sprite.h)
            return false;
        return true;
    }


    public boolean amIClickingOnYou(int mouseX, int mouseY)
    {
        if(mouseX >= x && mouseX <= x+w && mouseY >= y && mouseY <= y+h)
            return true;
        else
            return false;
    }

    public String toString()
    {
        return "Sprite: (" + x + ", " + y + ") w= " + w + ", h= " + h;
    }

    boolean isLink()
    {
        return false;
    }

    boolean isTile()
    {
        return false;
    }

    boolean isPot()
    {
        return false;
    }

    boolean isBoomerang()
    {
        return false;
    }


}