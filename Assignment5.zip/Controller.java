/*
Name: Bethany Terry

Date: 31 March 2023

Assignment Description:Create a Sprite class in order to implement
polymorphism in the program. Create a boomerang file and a pot file.
Add pots to map and allow Link to throw boomerangs to smash pots.
*/
import javax.swing.JFrame;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

//-----------------------------------------------------------
// Performs actions based on user input
//-----------------------------------------------------------
class Controller implements KeyListener, MouseListener, ActionListener
{
	View view;
	Model model;
	boolean keyLeft;
	boolean keyRight;
	boolean keyUp;
	boolean keyDown;
	boolean editMode = false;
	boolean pot = false;


	Controller(Model m)
	{
		model = m;
	}

	void setView(View v)
	{
		view = v;
	}

	public void keyPressed(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
			case KeyEvent.VK_ESCAPE: System.exit(0);
			case KeyEvent.VK_Q: System.exit(0);

//			case KeyEvent.VK_A: keyLeft = true; break;
//			case KeyEvent.VK_D: keyRight = true; break;
//			case KeyEvent.VK_W: keyUp = true; break;
//			case KeyEvent.VK_X: keyDown = true; break;

			case KeyEvent.VK_DOWN: keyDown = true; break;
			case KeyEvent.VK_UP: keyUp = true; break;
			case KeyEvent.VK_RIGHT: keyRight = true; break;
			case KeyEvent.VK_LEFT: keyLeft = true; break;
		}
	}

	public void keyReleased(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
			case KeyEvent.VK_S:
				Json ob = model.marshal();
				ob.save("map.json");
				System.out.println("Map saved");
				break;

			case KeyEvent.VK_L:
				Json loadFile = Json.load("map.json");
				try{
					model.unmarshal(loadFile);

				}catch(Exception s){
					model.unmarshal(loadFile);
				}
				System.out.println("Map is loaded");
				break;

			case KeyEvent.VK_E:
				if (editMode == false)
				{
					editMode = true;
					view.printToScreen = !view.printToScreen;
					System.out.println("Editing Mode Enabled");
				}
				else
				{
					System.out.println("Editing Mode Disabled");
					editMode = false;
					view.printToScreen = !view.printToScreen;
				}
				break;

			case KeyEvent.VK_P:
				if (pot == true)
				{
					pot = false;
					view.printToScreen = !view.printToScreen;
					System.out.println("Editing tiles");
				}
				else
				{
					System.out.println("Editing pots");
					pot = true;
					view.printToScreen = !view.printToScreen;
				}
				break;

			case KeyEvent.VK_CONTROL:
				Sprite b = new Boomerang(model.link.x, model.link.y);
				if(model.canAdd) model.sprites.add(b);
				break;

			case KeyEvent.VK_LEFT: keyLeft = false; break;
			case KeyEvent.VK_RIGHT: keyRight = false; break;
			case KeyEvent.VK_UP: keyUp = false; break;
			case KeyEvent.VK_DOWN: keyDown = false; break;
		}
	}

	public void keyTyped(KeyEvent e){ 	 }

	void update()
	{
		for(int i = 0; i < model.sprites.size(); i++)
		{
			if(model.sprites.get(i).isLink())
			{
				Sprite s = model.sprites.get(i);
				((Link)s).setPreviousCoordinates();
				if(keyRight)
				{
					s.x += ((Link)s).speed;
					((Link)s).updateImageNum(2);
				}
				if(keyLeft)
				{
					s.x -= ((Link)s).speed;
					((Link)s).updateImageNum(1);
				}
				if(keyDown)
				{
					s.y += ((Link)s).speed;
					((Link)s).updateImageNum(0);
				}
				if(keyUp)
				{
					s.y -= ((Link)s).speed;
					((Link)s).updateImageNum(3);
				}

				if(s.x >= View.scrollPosX + 700)
					View.scrollPosX += 700;
				if(s.x <= View.scrollPosX)
					View.scrollPosX -= 700;
				if(s.y <= View.scrollPosY)
					View.scrollPosY -= 500;
				if(s.y >= View.scrollPosY + 500)
					view.scrollPosY += 500;
			}
		}

	}

	public void mousePressed(MouseEvent e)
	{

	}

	public void mouseReleased(MouseEvent e)
	{
		if (editMode && !pot)
			model.addTile(e.getX() + view.scrollPosX, e.getY() + view.scrollPosY);
		if (editMode && pot)
			model.addPot(e.getX() + view.scrollPosX, e.getY() + view.scrollPosY);
	}

	public void mouseEntered(MouseEvent e) {    }
	public void mouseExited(MouseEvent e) {    }
	public void mouseClicked(MouseEvent e)
	{
		if(e.getY() < 100)
		{
			System.out.println("break here");
		}
	}
	public void actionPerformed(ActionEvent e){		}
}
