/*
Name: Bethany Terry

Date: 31 March 2023

Assignment Description:Create a Sprite class in order to implement
polymorphism in the program. Create a boomerang file and a pot file.
Add pots to map and allow Link to throw boomerangs to smash pots.
*/

import java.util.ArrayList;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;

public class Tile extends Sprite
{
	public Tile(int x, int y)
	{
		this.x = x;
		this.y = y;
		w = 50;
		h = 50;
		//-----------------------------------------------------------
		// load tile picture
		//-----------------------------------------------------------
		try
		{
			image = ImageIO.read(new File("tile.jpg"));

		}
		catch(Exception e)
		{
			e.printStackTrace(System.err);
			System.exit(1);
		}
	}
		public Tile(Json ob)
		{
			try
			{
				image = ImageIO.read(new File("tile.jpg"));

			}
			catch(Exception e)
			{
				e.printStackTrace(System.err);
				System.exit(1);
			}
			x = (int)ob.getLong("tile_x");
			y = (int)ob.getLong("tile_y");
			w = 50;
			h = 50;
		}


	public boolean amIClickingOnYou(int mouseX, int mouseY)
	{
		if(mouseX >= x && mouseX < x+w && mouseY >= y && mouseY < y+h)
			return true;
		else
			return false;
	}

	public Json marshal()
	{
		Json ob = Json.newObject();
		ob.add("tile_x", x);
		ob.add("tile_y", y);
		return ob;
	}

	public boolean update()
	{
		return true;
	}

	public void drawYourself(Graphics g)
	{
		g.drawImage(this.image, x - View.scrollPosX, y - View.scrollPosY, null);
	}

	@Override
	boolean isTile()
	{
		return true;
	}


	@Override
	public String toString()
	{
		return "Tile (x,y) = (" + x + ", " + y + "), w = " + w + ", h = " + h;
	}

}
