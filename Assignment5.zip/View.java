/*
Name: Bethany Terry

Date: 31 March 2023

Assignment Description:Create a Sprite class in order to implement
polymorphism in the program. Create a boomerang file and a pot file.
Add pots to map and allow Link to throw boomerangs to smash pots.
*/

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.io.File;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;

//-----------------------------------------------------------
// Create and extend area of graphical components
//-----------------------------------------------------------
class View extends JPanel
{
	Model model;
	boolean printToScreen = false;
	static int scrollPosX = 0, scrollPosY = 0;

	View(Controller c, Model m)
	{
		model = m;
		c.setView(this);
		printToScreen = false;
	}

	public static BufferedImage loadImage(String filename)
	{
		BufferedImage image = null;
		try
		{
			image = ImageIO.read(new File(filename));
		}
		catch(Exception e)
		{
			//System.out.println("ERROR");
		}

		return image;
	}

	public void updateImageNum()
	{

	}


	//-----------------------------------------------------------
	// color background, draw tiles
	//-----------------------------------------------------------
	public void paintComponent(Graphics g)
	{
		g.setColor(new Color(128, 255, 255));
		g.fillRect(0, 0, this.getWidth(), this.getHeight());

		for(int i = 0; i < model.sprites.size(); i++)
		{
			model.sprites.get(i).drawYourself(g);
		}

		if(printToScreen)
		{
			g.setColor(new Color(0));
			g.setFont(new Font("default", Font.BOLD, 16));
			g.drawString("Editing Mode Enabled", this.getWidth()/15, this.getHeight()/15);
		}
	}
}
