/*
Name: Bethany Terry

Date: 31 March 2023

Assignment Description:Create a Sprite class in order to implement
polymorphism in the program. Create a boomerang file and a pot file.
Add pots to map and allow Link to throw boomerangs to smash pots.
 */


import java.awt.Graphics;
import java.awt.image.BufferedImage;


public class Link extends Sprite
{
    int prevx = 200, prevy = 200;
    double speed;
    BufferedImage[] images;
    final int NUM_IMAGES = 44;
    final int MAX_IMAGES = 11; //how many images per direction
    int currentImage;
    int direction; // 0 = down, 1 = left, 2 = right, 3 = up


    public Link(int x, int y)
    {
        this.x = x;
        this.y = y;
        w = 60;
        h = 60;
        speed = 10;
        direction = 0;
        currentImage = 0;

        if(images != null) return;

        images = new BufferedImage[NUM_IMAGES];
        for (int i = 0; i < NUM_IMAGES; i++)
        {
            images[i] = View.loadImage("link_images/link" + (i+1) + ".png");
        }

    }

    public boolean update()
    {
        return true;
    }

    public void updateImageNum(int dir)
    {
        direction = dir;
        currentImage++;
        if (currentImage > MAX_IMAGES-1)
            currentImage = 1;
    }

    public void setPreviousCoordinates()
    {
        prevx = x;
        prevy = y;
    }

    public void drawYourself(Graphics g)
    {
        g.drawImage(this.images[currentImage+direction*MAX_IMAGES], x - View.scrollPosX, y - View.scrollPosY, w, h, null);
    }

    public void getOutOfTile()
    {
        x = prevx;
        y = prevy;

    }
    @Override
    boolean isLink()
    {
        return true;
    }


    @Override
    public String toString()
    {
        return "Tile (x,y) = (" + x + ", " + y + "), w = " + w + ", h = " + h;
    }

    public Json marshal()
    {
        Json ob = Json.newObject();
        ob.add("x", x);
        ob.add("y", y);
        ob.add("w", w);
        ob.add("h", h);
        return ob;
    }

}


