# Bethany Terry
# 30 April 2023
# In this assignment, I rewrote my Zelda level in Python but without
# the editing capabilities. Link is able to move between rooms, throw
# boomerangs, and interact with pots.

import pygame
import time

from pygame.locals import*
from time import sleep

#************************************************************************
# SPRITE CLASS
#************************************************************************
class Sprite():
	# MAX_Instances = 2
	# Inst_created = 0

	# def __new__(cls, *args, **kwargs): #actual constructor - not needed for ass8
	# 	print("new is called")
	# 	obj = super().__new__(cls)
	# 	if(cls.Inst_created >= cls.MAX_Instances):
	# 		raise ValueError("Cannot create more objects")
	# 	cls.Inst_created += 1


	def __init__(self, x, y, w, h, im): #not a constructor but does the initialization
		self.x = x
		self.y = y
		self.w = w
		self.h = h
		self.image = pygame.image.load(im)

	def collisionDetection(self, sprite):
		if(self.x + self.w < sprite.x):
			return False
		if(self.x > sprite.x + sprite.w):
			return False
		if(self.y + self.h < sprite.y):
			return False
		if(self.y > sprite.y + sprite.h):
			return False
		return True

#************************************************************************
# LINK CLASS
#************************************************************************
class Link(Sprite):
	speed = 10
	prevx = 200
	prevy = 200
	NUM_IMAGES = 44
	MAX_IMAGES = 11
	currentImage = 0
	direction = 0 # 0 = down, 1 = left, 2 = right, 3 = up
	def __init__(self, x, y):
		# Sprite.__init__(self, x, y, w, h, im)
		super().__init__(x, y, 60, 60, "link_images/link1.png")

		self.images = []

		for i in range(self.NUM_IMAGES):
			image = "link_images/link" + str(i+1) + ".png"
			self.images.append(pygame.image.load(image))

	def update(self):
		return True
		#print(isinstance(link,Link))
	
	def updateImageNum(self, dir):
		self.direction = dir
		self.currentImage += 1
		if(self.currentImage > self.MAX_IMAGES-1):
			self.currentImage = 1

	def setPreviousCoordinates(self):
		self.prevx = self.x
		self.prevy = self.y

	def drawYourself(self, screen):
		LOCATION = self.x - View.scrollPosX, self.y - View.scrollPosY
		screen.blit(self.images[self.currentImage+self.direction*self.MAX_IMAGES], LOCATION)


	def getOutOfTile(self):
		self.x = self.prevx
		self.y = self.prevy
		

#************************************************************************
# TILE CLASS
#************************************************************************
class Tile(Sprite):
	def __init__(self, x, y):
		super().__init__(x, y, 50, 50, "tile.jpg")

	def drawYourself(self, screen):
		LOCATION = self.x - View.scrollPosX, self.y - View.scrollPosY
		screen.blit(self.image, LOCATION)

	def update(self):
		return True

#************************************************************************
# POT CLASS
#************************************************************************
class Pot(Sprite):
	def __init__(self, x, y):
		super().__init__(x, y, 30, 30, "pot.png")
		self.xdirection = 0
		self.ydirection = 0
		self.speed = 15
		self.isValid = True
		self.isBroken = False
		self.isBrokenTimer = 10

	def update(self):
		self.x += self.speed * self.xdirection
		self.y += self.speed * self.ydirection
		if(self.isBroken):
			self.isBrokenTimer -= 1

		if(self.isBrokenTimer <= 0):
			self.isValid = False

		#print(self.isValid)

		return self.isValid

	def potHasBeenBroken(self):
		self.image = pygame.image.load("pot_broken.png")
		self.isBroken = True
		self.speed = 0

	def drawYourself(self, screen):
		#if(self.isValid):
		LOCATION = self.x - View.scrollPosX, self.y - View.scrollPosY
		screen.blit(self.image, LOCATION)
		# Model.sprites.remove()

#************************************************************************
# BOOMERANG CLASS
#************************************************************************
class Boomerang(Sprite):
	def __init__(self, x, y):
		super(Boomerang, self).__init__(x, y, 30, 30, "boomerang1.png")
		self.xdirection = 0
		self.ydirection = 0
		self.speed = 15
		self.isValid = True
		self.isBroken = False
		self.isBrokenTimer = 10

	def update(self):
		self.x += self.speed * self.xdirection
		self.y += self.speed * self.ydirection
		return self.isValid

	def drawYourself(self, screen):
		if(self.isValid):
			LOCATION = self.x - View.scrollPosX, self.y - View.scrollPosY
			image = pygame.transform.scale(self.image,(30,30))
			screen.blit(image, LOCATION)
		

#************************************************************************
# MODEL CLASS
#************************************************************************
class Model():
	def __init__(self):
		self.dest_x = 0
		self.dest_y = 0
		self.sprites = []

		for i in range(0,1500,50):
			self.sprites.append(Tile(i,0))
			if(i!=200):
				if(i!=250):
					if(i!=1000):
						if(i!=1050):
							self.sprites.append(Tile(i,550))
			self.sprites.append(Tile(i,1100))
		for i in range(0,1200,50):
			self.sprites.append(Tile(0,i))
			if(i!=250):
				if(i!=300):
					if(i!=800):
						if(i!=850):
							self.sprites.append(Tile(700,i))
			self.sprites.append(Tile(1400,i))
		self.sprites.append(Tile(50, 50))
		self.sprites.append(Tile(50, 100))
		self.sprites.append(Tile(100, 50))
		self.sprites.append(Tile(100, 100))
		self.sprites.append(Tile(50, 150))
		self.sprites.append(Tile(150, 50))
		self.sprites.append(Tile(50, 500))
		self.sprites.append(Tile(650, 50))
		self.sprites.append(Tile(650, 100))
		self.sprites.append(Tile(650, 500))
		self.sprites.append(Tile(800, 50))
		self.sprites.append(Tile(750, 50))
		self.sprites.append(Tile(750, 100))
		self.sprites.append(Tile(750, 500))
		self.sprites.append(Tile(1350, 50))
		self.sprites.append(Tile(1300, 50))
		self.sprites.append(Tile(1350, 100))
		self.sprites.append(Tile(1350, 500))
		self.sprites.append(Tile(1000, 200))
		self.sprites.append(Tile(1150, 200))
		self.sprites.append(Tile(1000, 350))
		self.sprites.append(Tile(1000, 400))
		self.sprites.append(Tile(1050, 400))
		self.sprites.append(Tile(1100, 400))
		self.sprites.append(Tile(1150, 400))
		self.sprites.append(Tile(1150, 350))
		self.sprites.append(Tile(1050, 1050))
		self.sprites.append(Tile(1050, 1000))
		self.sprites.append(Tile(1050, 950))
		self.sprites.append(Tile(1050, 900))
		self.sprites.append(Tile(1000, 900))
		self.sprites.append(Tile(950, 900))
		self.sprites.append(Tile(1150, 900))
		self.sprites.append(Tile(1100, 900))
		self.sprites.append(Tile(1000, 850))
		self.sprites.append(Tile(1050, 850))
		self.sprites.append(Tile(1100, 850))
		self.sprites.append(Tile(1050, 800))
		self.sprites.append(Tile(750, 1050))
		self.sprites.append(Tile(650, 1050))
		self.sprites.append(Tile(1350, 1050))
		self.sprites.append(Tile(50, 1050))
		self.sprites.append(Tile(50, 600))
		self.sprites.append(Tile(650, 600))
		self.sprites.append(Tile(750, 600))
		self.sprites.append(Tile(1350, 600))
		self.sprites.append(Tile(350, 800))
		self.sprites.append(Tile(350, 750))
		self.sprites.append(Tile(350, 900))
		self.sprites.append(Tile(350, 950))
		self.sprites.append(Tile(400, 850))
		self.sprites.append(Tile(300, 850))
		self.sprites.append(Tile(250, 850))
		self.sprites.append(Tile(350, 850))
		self.sprites.append(Tile(450, 850))
		self.sprites.append(Tile(400, 350))
		self.sprites.append(Tile(450, 300))
		self.sprites.append(Tile(450, 250))
		self.sprites.append(Tile(400, 200))
		self.sprites.append(Tile(350, 400))
		self.sprites.append(Tile(350, 250))
		self.sprites.append(Tile(300, 200))
		self.sprites.append(Tile(250, 250))
		self.sprites.append(Tile(250, 300))
		self.sprites.append(Tile(300, 350))

		self.sprites.append(Pot(550, 400))
		self.sprites.append(Pot(400, 100))
		self.sprites.append(Pot(100, 350))
		self.sprites.append(Pot(900, 350))
		self.sprites.append(Pot(1100, 100))
		self.sprites.append(Pot(1300, 300))
		self.sprites.append(Pot(1300, 800))
		self.sprites.append(Pot(1000, 700))
		self.sprites.append(Pot(850, 950))
		self.sprites.append(Pot(150, 950))
		self.sprites.append(Pot(550, 1000))
		self.sprites.append(Pot(250, 700))
		self.sprites.append(Pot(550, 750))

		self.link = Link(150,200)
		self.sprites.append(self.link)

	def update(self):
		for sprite in self.sprites:
			sprite.update()
		for sprite1 in self.sprites:
			for sprite2 in self.sprites:
				if(sprite1.collisionDetection(sprite2)):
					if(isinstance (sprite1,Link)):
						if(isinstance (sprite2,Tile)):
							sprite1.getOutOfTile()
						if(isinstance(sprite2,Pot)):
							if(sprite1.direction == 0):
								sprite2.ydirection = 1
							if(sprite1.direction == 1):
								sprite2.xdirection = -1
							if(sprite1.direction == 2):
								sprite2.xdirection = 1
							if(sprite1.direction == 3):
								sprite2.ydirection = -1
						if(isinstance(sprite2,Boomerang)):
							if(sprite1.direction == 0):
								sprite2.ydirection = 1
							if(sprite1.direction == 1):
								sprite2.xdirection = -1
							if(sprite1.direction == 2):
								sprite2.xdirection = 1
							if(sprite1.direction == 3):
								sprite2.ydirection = -1
					if(isinstance(sprite1,Pot)):
						if(isinstance(sprite2,Tile)):
							sprite1.potHasBeenBroken()
					if(isinstance(sprite1,Boomerang)):
						if(isinstance(sprite2,Tile)):
							sprite1.isValid = False
						if(isinstance(sprite2,Pot)):
							sprite2.potHasBeenBroken()
							sprite1.isValid = False
			if(isinstance(sprite1, Pot)):
				if(sprite1.isValid == False):
					self.sprites.remove(sprite1)
					break
			elif(isinstance(sprite1, Boomerang)):
				if(sprite1.isValid == False):
					self.sprites.remove(sprite1) #check if valid is false for pot or boom then remove
					break
				

#************************************************************************
# VIEW CLASS
#************************************************************************
class View():
	scrollPosX = 0
	scrollPosY = 0
	def __init__(self, model):
		screen_size = (750,600)
		self.screen = pygame.display.set_mode(screen_size, 32) #what does the 32 mean?
		self.model = model

	def update(self):
		self.screen.fill([0, 255, 255])
		for sprite in self.model.sprites:
			sprite.drawYourself(self.screen)
		pygame.display.flip() 

#************************************************************************
# CONTROLLER CLASS
#************************************************************************
class Controller():
	def __init__(self, model):
		self.model = model
		self.keep_going = True
		self.ctrl_pressed = False

	def update(self):
		for event in pygame.event.get():
			if event.type == QUIT:
				self.keep_going = False
			elif event.type == KEYDOWN:
				if event.key == K_ESCAPE:
					self.keep_going = False
			elif event.type == KEYUP:
				if event.key == pygame.K_LCTRL:
					self.boomerang = Boomerang(self.model.link.x, self.model.link.y)
					self.model.sprites.append(self.boomerang)


		keys = pygame.key.get_pressed()

		for sprite in self.model.sprites:
			if(isinstance(sprite, Link)):
				sprite.setPreviousCoordinates()
				if keys[K_RIGHT]:
					sprite.x += sprite.speed
					sprite.updateImageNum(2)
				if keys[K_LEFT]:
					sprite.x -= sprite.speed
					sprite.updateImageNum(1)
				if keys[K_DOWN]:
					sprite.y += sprite.speed
					sprite.updateImageNum(0)
				if keys[K_UP]:
					sprite.y -= sprite.speed
					sprite.updateImageNum(3)

				if(sprite.x >= View.scrollPosX + 700):
					View.scrollPosX += 700
				if(sprite.x <= View.scrollPosX):
					View.scrollPosX -= 700
				if(sprite.y <= View.scrollPosY):
					View.scrollPosY -= 550
				if(sprite.y >= View.scrollPosY + 550):
					View.scrollPosY += 550
		

print("Use the arrow keys to move. Press Esc to quit.")
pygame.init()
m = Model()
v = View(m)
c = Controller(m)
while c.keep_going:
	c.update()
	m.update()
	v.update()
	sleep(0.04)
